package umariana.mundial;

public class NombreDuplicadoException extends Exception {
    
    public NombreDuplicadoException(String message) {
        super(message);
    }
}
