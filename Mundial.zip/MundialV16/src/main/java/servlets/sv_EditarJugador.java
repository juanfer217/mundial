package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import umariana.mundial.GestionarJugador;

@WebServlet(name = "sv_EditarJugador", urlPatterns = {"/sv_EditarJugador"})
public class sv_EditarJugador extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener los parámetros del formulario
        int idJugador = Integer.parseInt(request.getParameter("idJugador"));
        String nombreJugador = request.getParameter("nombreJugador");
        int edad = Integer.parseInt(request.getParameter("edad"));
        double altura = Double.parseDouble(request.getParameter("altura"));
        double peso = Double.parseDouble(request.getParameter("peso"));
        double salario = Double.parseDouble(request.getParameter("salario"));
        String posicion = request.getParameter("posicion");

        // Obtener la imagen anterior y la nueva imagen (si se proporciona)
        String imagenAnterior = request.getParameter("imagenAnterior");
        Part imagenPart = request.getPart("nuevaImagen");

        // Definir la ruta para guardar la nueva imagen si se carga una nueva
        String imagenPath = null;
        if (imagenPart != null && imagenPart.getSize() > 0) {
            // Obtener la ruta de la aplicación web
            String rutaAplicacion = request.getServletContext().getRealPath("/");

            // Definir la ruta donde se guardará la nueva imagen
            imagenPath = imagenPart.getSubmittedFileName();

            // Guardar el archivo en la carpeta designada
            imagenPart.write(rutaAplicacion + imagenPath);
        } else {
            // Si no se proporciona una nueva imagen, usar la imagen anterior
            imagenPath = imagenAnterior;
        }

        try {
            // Llamar al método editarJugador de GestionarJugador para editar el jugador
            GestionarJugador.editarJugador(idJugador, nombreJugador, edad, altura, peso, salario, posicion, imagenPath);

            // Redirigir a la página de jugadores o a una página de éxito
            response.sendRedirect("verJugador.jsp");
        } catch (NumberFormatException e) {
            // Manejar el caso en que el parámetro idJugador no sea un número válido
            response.sendRedirect("error.jsp");
        } catch (IOException e) {
            // Manejar otras excepciones de E/S
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
