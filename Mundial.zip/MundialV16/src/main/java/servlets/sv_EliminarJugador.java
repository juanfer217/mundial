package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import umariana.mundial.GestionarJugador;

@WebServlet("/eliminarJugador.do")
public class sv_EliminarJugador extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el ID del jugador a eliminar
        int idJugador = Integer.parseInt(request.getParameter("idJugador"));
        try {
            // Eliminar el jugador utilizando GestionarJugador
            GestionarJugador.eliminarJugador(idJugador);

            // Redirigir a una página de confirmación
            response.sendRedirect("verJugador.jsp");
        } catch (IOException e) {
            // Manejo de errores
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
